# 🧠 Adaptive CAT QA Tutor

This Streamlit app generates adaptive Quant questions for CAT exam preparation using GPT-4 + LangChain.

## 🔧 Features
- Generate topic-wise QA questions (Easy/Medium/Hard)
- Get step-by-step GPT solutions
- Submit your answer and get instant feedback
- Track your accuracy over time with charts
- Store performance history in SQLite

## 🚀 Run Locally

```bash
pip install -r requirements.txt
streamlit run adaptive_qa_generator.py
```

## 🌐 Deploy on Streamlit Cloud
1. Fork this repo
2. Go to [streamlit.io/cloud](https://streamlit.io/cloud) and link your GitHub
3. Click 'Deploy'
